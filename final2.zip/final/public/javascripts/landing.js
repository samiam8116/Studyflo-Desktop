$( document ).ready(function() {
    $( "input[type='radio']" ).prop( "checked", true ).checkboxradio( "refresh" );
  });